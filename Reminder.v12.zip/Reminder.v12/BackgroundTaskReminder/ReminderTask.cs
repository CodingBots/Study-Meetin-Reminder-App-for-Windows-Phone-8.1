﻿using Newtonsoft.Json;
using SharedLibraries;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel.Background;
using Windows.Storage;

namespace BackgroundTaskReminder
{
    public sealed class ReminderTask : IBackgroundTask
    {
        public async void Run(IBackgroundTaskInstance taskInstance)
        {
            BackgroundTaskDeferral deferral = taskInstance.GetDeferral();

            await GetReminder();

            deferral.Complete();
        }

        private async Task GetReminder()
        {
            try
            {
                object temp = await GetPendingReminder();

                ObservableCollection<Reminder> pendingReminders = new ObservableCollection<Reminder>();

                ObservableCollection<Reminder> tempCollection = new ObservableCollection<Reminder>();
                tempCollection = (ObservableCollection<Reminder>)temp;

                ObservableCollection<Reminder> completed = new ObservableCollection<Reminder>();
                try
                {
                    StorageFile file = await ApplicationData.Current.LocalFolder.GetFileAsync("Completed.txt");
                    string jsonString = await FileIO.ReadTextAsync(file);
                    completed = JsonConvert.DeserializeObject<ObservableCollection<Reminder>>(jsonString);
                }
                catch(Exception ex)
                {
                    completed = new ObservableCollection<Reminder>();
                }

                if (tempCollection.Count > 0)
                {
                    foreach (Reminder reminder in tempCollection)
                    {
                        DateTime date = Convert.ToDateTime(reminder.ReminderDate);
                        if (date <= DateTime.Now)
                        {
                            if (reminder.Type == "GridMeeting")
                                ToastNotificationHelper.SetReminder("Meeting in " + reminder.Location, reminder.Agenda);
                            else if (reminder.Type == "GridStudy")
                                ToastNotificationHelper.SetReminder(reminder.StudyType, reminder.Title);

                            reminder.Status = "Completed";
                            completed.Add(reminder);
                        }
                        else
                        {
                            pendingReminders.Add(reminder);
                        }
                    }

                    JsonHelper jsonHelper = new JsonHelper();
                    if (pendingReminders.Count > 0)
                        jsonHelper.SerializeReminderData(pendingReminders, "PendingReminders.txt");
                    else
                        jsonHelper.DeleteFile("PendingReminders.txt");

                    if (completed.Count > 0)
                        jsonHelper.SerializeReminderData(completed, "Completed.txt");
                    else
                        jsonHelper.DeleteFile("Completed.txt");
                }
            }
            catch (Exception ex)
            { }
        }

        private async Task<object> GetPendingReminder()
        {
            try
            {
                StorageFile file = await ApplicationData.Current.LocalFolder.GetFileAsync("PendingReminders.txt");
                string jsonString = await FileIO.ReadTextAsync(file);
                return JsonConvert.DeserializeObject<ObservableCollection<Reminder>>(jsonString);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

    }
}