﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedLibraries
{
    public class Reminder
    {
        public static int staticId = 0;

        private int id;
        public int ID 
        {
            get 
            {
                return id;
            }
            private set
            {
                id = value;
            }
        }

        private string type;
        public string Type 
        {
            get
            {
                return type;
            }
            set
            {
                type = value;
                if (type == "GridMeeting")
                {
                    MeetingWith = new ObservableCollection<string>();
                }
                else if (type == "GridStudy")
                {
                    GroupMembers = new ObservableCollection<string>();
                }
            }
        }
        public ObservableCollection<string> MeetingWith;
        public ObservableCollection<string> GroupMembers;
        public string Instructor { get; set; }
        public string Agenda {get ; set;}
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string StudyType { get; set; }
        public string Subject { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string DueDate { get; set; }
        public string Priority { get; set;}
        public string Location { get; set; }
        public string ReminderDate { get; set; }
        public string Status { get; set; }

        public Reminder(string type)
        {
            this.type = type;
            ID = staticId;
            staticId++;
            Status = "Incomplete";
        }
    }
}
