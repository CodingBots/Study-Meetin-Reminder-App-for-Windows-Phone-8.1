﻿using NotificationsExtensions.ToastContent;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Notifications;

namespace SharedLibraries
{
    public class ToastNotificationHelper
    {
        public static void SetReminder(string text01, string text02)
        {
            IToastImageAndText02 toast = ToastContentFactory.CreateToastImageAndText02();
            toast.TextHeading.Text = text01;
            toast.TextBodyWrap.Text = text02;
            ToastNotification notification = toast.CreateNotification();
            ToastNotificationManager.CreateToastNotifier().Show(notification);
        }
    }
}
