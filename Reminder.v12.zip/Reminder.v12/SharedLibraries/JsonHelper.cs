﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;

namespace SharedLibraries
{
    public class JsonHelper
    {
        public async void SerializeReminderData(object obj, string filename)
        {
            try
            {
                StorageFile file = await ApplicationData.Current.LocalFolder.CreateFileAsync(filename, CreationCollisionOption.ReplaceExisting);
                string jsonString = JsonConvert.SerializeObject(obj, Formatting.Indented);
                await FileIO.WriteTextAsync(file, jsonString);
            }
            catch (Exception ex)
            {}
        }

        public async Task<object> DeserializeReminderData(string filename)
        {
            try
            {
                StorageFile file = await ApplicationData.Current.LocalFolder.GetFileAsync(filename);
                string jsonString = await FileIO.ReadTextAsync(file);
                return JsonConvert.DeserializeObject<object>(jsonString);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async void DeleteFile(string filename)
        {
            try
            {
                StorageFile file = await ApplicationData.Current.LocalFolder.GetFileAsync(filename);
                await file.DeleteAsync();
            }
            catch (Exception ex)
            {
            }
        }
    }
}
