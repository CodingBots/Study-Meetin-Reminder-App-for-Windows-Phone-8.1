﻿using Meeting_Reminder.Common;
using Newtonsoft.Json;
using SharedLibraries;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.ApplicationModel.Background;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.Storage;
using Windows.UI.Popups;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Basic Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace Meeting_Reminder
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class AddReminder2 : Page
    {
        public Reminder reminder;
        ObservableCollection<string> instructors = new ObservableCollection<string>();
        ObservableCollection<string> groupMembers = new ObservableCollection<string>();


        private NavigationHelper navigationHelper;
        private ObservableDictionary defaultViewModel = new ObservableDictionary();

        public AddReminder2()
        {
            this.InitializeComponent();

            this.navigationHelper = new NavigationHelper(this);
            this.navigationHelper.LoadState += this.NavigationHelper_LoadState;
            this.navigationHelper.SaveState += this.NavigationHelper_SaveState;

            Loaded += AddReminder2_Loaded;
        }

        async void AddReminder2_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                StorageFile file = await ApplicationData.Current.LocalFolder.GetFileAsync("Instructors.txt");
                string jsonString = await FileIO.ReadTextAsync(file);
                instructors = JsonConvert.DeserializeObject<ObservableCollection<string>>(jsonString);
                ComboboxInstructor.ItemsSource = instructors;
            }
            catch (Exception ex)
            { }

            if (reminder.Type == "GridMeeting")
            {
                GridMeeting.Visibility = Windows.UI.Xaml.Visibility.Visible;
                GridStudy.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            }
            else if (reminder.Type == "GridStudy")
            {
                GridMeeting.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
                GridStudy.Visibility = Windows.UI.Xaml.Visibility.Visible;
            }
        }

        /// <summary>
        /// Gets the <see cref="NavigationHelper"/> associated with this <see cref="Page"/>.
        /// </summary>
        public NavigationHelper NavigationHelper
        {
            get { return this.navigationHelper; }
        }

        /// <summary>
        /// Gets the view model for this <see cref="Page"/>.
        /// This can be changed to a strongly typed view model.
        /// </summary>
        public ObservableDictionary DefaultViewModel
        {
            get { return this.defaultViewModel; }
        }

        /// <summary>
        /// Populates the page with content passed during navigation.  Any saved state is also
        /// provided when recreating a page from a prior session.
        /// </summary>
        /// <param name="sender">
        /// The source of the event; typically <see cref="NavigationHelper"/>
        /// </param>
        /// <param name="e">Event data that provides both the navigation parameter passed to
        /// <see cref="Frame.Navigate(Type, Object)"/> when this page was initially requested and
        /// a dictionary of state preserved by this page during an earlier
        /// session.  The state will be null the first time a page is visited.</param>
        private void NavigationHelper_LoadState(object sender, LoadStateEventArgs e)
        {
        }

        /// <summary>
        /// Preserves state associated with this page in case the application is suspended or the
        /// page is discarded from the navigation cache.  Values must conform to the serialization
        /// requirements of <see cref="SuspensionManager.SessionState"/>.
        /// </summary>
        /// <param name="sender">The source of the event; typically <see cref="NavigationHelper"/></param>
        /// <param name="e">Event data that provides an empty dictionary to be populated with
        /// serializable state.</param>
        private void NavigationHelper_SaveState(object sender, SaveStateEventArgs e)
        {
        }

        #region NavigationHelper registration

        /// <summary>
        /// The methods provided in this section are simply used to allow
        /// NavigationHelper to respond to the page's navigation methods.
        /// <para>
        /// Page specific logic should be placed in event handlers for the  
        /// <see cref="NavigationHelper.LoadState"/>
        /// and <see cref="NavigationHelper.SaveState"/>.
        /// The navigation parameter is available in the LoadState method 
        /// in addition to page state preserved during an earlier session.
        /// </para>
        /// </summary>
        /// <param name="e">Provides data for navigation methods and event
        /// handlers that cannot cancel the navigation request.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            this.navigationHelper.OnNavigatedTo(e);
            dynamic expando = e.Parameter as ExpandoObject;

            if ((string)expando.Type == "GridMeeting")
            {
                reminder = new Reminder("GridMeeting");
                reminder.MeetingWith = expando.MeetingWith as ObservableCollection<string>;
                reminder.Agenda = expando.Agenda as string;
                reminder.StartDate = expando.StartDate as string;
                reminder.EndDate = expando.EndDate as string;
                reminder.Priority = expando.Priority as string;
            }
            else if ((string)expando.Type == "GridStudy")
            {
                reminder = new Reminder("GridStudy");
                reminder.StudyType = expando.StudyType as string;
                reminder.Subject = expando.Subject as string;
                reminder.Title = expando.Title as string;
                reminder.Description = expando.Description as string;
                reminder.DueDate = expando.DueDate as string;
                reminder.Priority = expando.Priority as string;
            }
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            this.navigationHelper.OnNavigatedFrom(e);
        }

        #endregion

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(textboxInstructor.Text.Trim()))
            {
                await new MessageDialog("Type information").ShowAsync();
                return;
            }
            instructors.Add(textboxInstructor.Text);
            ComboboxInstructor.ItemsSource = instructors;
            textboxInstructor.Text = "";

            if (ComboboxInstructor.Items.Count > 0)
                App.jsonHelper.SerializeReminderData(instructors, "Instructors.txt");
        }

        private async void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(textboxGroupMember.Text.Trim()))
            {
                await new MessageDialog("Type information").ShowAsync();
                return;
            }
            groupMembers.Add(textboxGroupMember.Text);
            Comboboxgroupmembers.ItemsSource = groupMembers;
            textboxGroupMember.Text = "";

            if (groupMembers.Count > 1)
                textblockGroupmembers.Text = "Your group members are " + groupMembers[0] + " and " + (groupMembers.Count - 1) + " other";
            else if (groupMembers.Count == 1)
                textblockGroupmembers.Text = "Your group member is " + groupMembers[0] + " only, you can add more";
        }

        private async void ButtonNext_Click(object sender, RoutedEventArgs e)
        {
            if (await Validation())
            {
                DateTime dateToRemind = new DateTime(DatePickerReminderDate.Date.Year, DatePickerReminderDate.Date.Month, DatePickerReminderDate.Date.Day,
                                                        TimePickerReminderTime.Time.Hours, TimePickerReminderTime.Time.Minutes, TimePickerReminderTime.Time.Seconds);
                
                double minutes = dateToRemind.Subtract(DateTime.Now).TotalMinutes;
                if (minutes <= 15)
                {
                    await new MessageDialog("Reminder should be set for more than 15 minutes").ShowAsync();
                    return;
                }

                SerializeReminder();

                if (ToggleSwitchSetReminder.IsOn == true)
                {
                    RegisterBackgoundWorker(minutes, dateToRemind);
                    await new MessageDialog("Saved with reminder").ShowAsync();
                }
                else
                {
                    await new MessageDialog("Saved without reminder").ShowAsync();
                }

                this.Frame.Navigate(typeof(UpcommingReminders));
            }
        }

        private async Task<bool> Validation()
        {
            if (reminder.Type == "GridMeeting")
            {
                if (string.IsNullOrEmpty(textBoxLocation.Text))
                {
                    await new MessageDialog("Type location").ShowAsync();
                    return false;
                }
                return true;
            }
            else if (reminder.Type == "GridStudy")
            {
                if (toggleSwitchIndividual.IsOn)
                {
                    if (groupMembers.Count < 1)
                    {
                        await new MessageDialog("Add group members").ShowAsync();
                        return false;
                    }
                }
                if(string.IsNullOrEmpty((string)ComboboxInstructor.SelectedValue))
                {
                    await new MessageDialog("Add instructor").ShowAsync();
                    return false;
                }
                return true;
            }
            return false;
        }

        private void SerializeReminder()
        {
            if (reminder.Type == "GridMeeting")
            {
                reminder.Location = textBoxLocation.Text;
            }
            else if (reminder.Type == "GridStudy")
            {
                reminder.GroupMembers = groupMembers;
                reminder.Instructor = ComboboxInstructor.SelectedValue as string;
            }

            if (ToggleSwitchSetReminder.IsOn == true)
            {
                DateTime dateToRemind = new DateTime(DatePickerReminderDate.Date.Year, DatePickerReminderDate.Date.Month, DatePickerReminderDate.Date.Day,
                                                        TimePickerReminderTime.Time.Hours, TimePickerReminderTime.Time.Minutes, TimePickerReminderTime.Time.Seconds);

                reminder.ReminderDate = dateToRemind.ToString();
            }

            if (App.pendingReminders == null)
                App.pendingReminders = new ObservableCollection<Reminder>();

            App.pendingReminders.Add(reminder);
            App.jsonHelper.SerializeReminderData(App.pendingReminders, "PendingReminders.txt");
        }

        private async void RegisterBackgoundWorker(double minutes, DateTime dateToPost)
        {
            BackgroundTaskBuilder builder = new BackgroundTaskBuilder();
            int x = (int)minutes;
            uint min = uint.Parse(x.ToString());
            builder.Name = "Remind after " + min.ToString() + " minutes";
            builder.TaskEntryPoint = "BackgroundTaskReminder.ReminderTask";

            try
            {
                TimeTrigger timer = new TimeTrigger(min, true);
                builder.SetTrigger(timer);
                await BackgroundExecutionManager.RequestAccessAsync();
                BackgroundTaskRegistration reg = builder.Register();
            }
            catch
            {
                // time less then 15 minutes
            }
        }

        private void AppBarButton_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(UpcommingReminders));
        }

        private void AppBarButton_Click_1(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPage));
        }
    }
}
