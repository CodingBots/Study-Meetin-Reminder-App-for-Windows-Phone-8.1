﻿using Meeting_Reminder.Common;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.Storage;
using Windows.UI.Popups;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Basic Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace Meeting_Reminder
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class AddReminder1 : Page
    {
        List<string> reminders = new List<string>() { "Meeting Reminder", "Study Reminder" };
        List<string> priority = new List<string>() { "Important", "Normal", "Regular" };
        List<string> studyType = new List<string>() { "Assignment", "Quiz", "Project", "Seminar", "Workshop" };
        ObservableCollection<string> subjects;
        ObservableCollection<string> meetingWith;

        private NavigationHelper navigationHelper;
        private ObservableDictionary defaultViewModel = new ObservableDictionary();

        public AddReminder1()
        {
            this.InitializeComponent();

            this.navigationHelper = new NavigationHelper(this);
            this.navigationHelper.LoadState += this.NavigationHelper_LoadState;
            this.navigationHelper.SaveState += this.NavigationHelper_SaveState;
            Loaded += Add_Loaded;
        }

        async void Add_Loaded(object sender, RoutedEventArgs e)
        {
            ComboboxReminderType.ItemsSource = reminders;
            ComboBoxPriority.ItemsSource = priority;
            ComboboxStudyType.ItemsSource = studyType;

            if (meetingWith == null)
                meetingWith = new ObservableCollection<string>();

            if (meetingWith.Count > 0)
                ComboboxMeetingWith.Visibility = Windows.UI.Xaml.Visibility.Visible;
            else
                ComboboxMeetingWith.Visibility = Windows.UI.Xaml.Visibility.Collapsed;

            try
            {
                StorageFile file = await ApplicationData.Current.LocalFolder.GetFileAsync("Subjects.txt");
                string jsonString = await FileIO.ReadTextAsync(file);
                subjects = JsonConvert.DeserializeObject<ObservableCollection<string>>(jsonString);
                ComboboxSubjects.ItemsSource = subjects;
            }
            catch (Exception ex)
            { }
        }

        /// <summary>
        /// Gets the <see cref="NavigationHelper"/> associated with this <see cref="Page"/>.
        /// </summary>
        public NavigationHelper NavigationHelper
        {
            get { return this.navigationHelper; }
        }

        /// <summary>
        /// Gets the view model for this <see cref="Page"/>.
        /// This can be changed to a strongly typed view model.
        /// </summary>
        public ObservableDictionary DefaultViewModel
        {
            get { return this.defaultViewModel; }
        }

        /// <summary>
        /// Populates the page with content passed during navigation.  Any saved state is also
        /// provided when recreating a page from a prior session.
        /// </summary>
        /// <param name="sender">
        /// The source of the event; typically <see cref="NavigationHelper"/>
        /// </param>
        /// <param name="e">Event data that provides both the navigation parameter passed to
        /// <see cref="Frame.Navigate(Type, Object)"/> when this page was initially requested and
        /// a dictionary of state preserved by this page during an earlier
        /// session.  The state will be null the first time a page is visited.</param>
        private void NavigationHelper_LoadState(object sender, LoadStateEventArgs e)
        {
        }

        /// <summary>
        /// Preserves state associated with this page in case the application is suspended or the
        /// page is discarded from the navigation cache.  Values must conform to the serialization
        /// requirements of <see cref="SuspensionManager.SessionState"/>.
        /// </summary>
        /// <param name="sender">The source of the event; typically <see cref="NavigationHelper"/></param>
        /// <param name="e">Event data that provides an empty dictionary to be populated with
        /// serializable state.</param>
        private void NavigationHelper_SaveState(object sender, SaveStateEventArgs e)
        {
        }

        #region NavigationHelper registration

        /// <summary>
        /// The methods provided in this section are simply used to allow
        /// NavigationHelper to respond to the page's navigation methods.
        /// <para>
        /// Page specific logic should be placed in event handlers for the  
        /// <see cref="NavigationHelper.LoadState"/>
        /// and <see cref="NavigationHelper.SaveState"/>.
        /// The navigation parameter is available in the LoadState method 
        /// in addition to page state preserved during an earlier session.
        /// </para>
        /// </summary>
        /// <param name="e">Provides data for navigation methods and event
        /// handlers that cannot cancel the navigation request.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            this.navigationHelper.OnNavigatedTo(e);
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            this.navigationHelper.OnNavigatedFrom(e);
        }

        #endregion

        private void ComboboxReminderType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ComboboxReminderType.SelectedIndex != -1)
            {
                string reminder = ComboboxReminderType.SelectedValue as string;

                if (reminder == "Meeting Reminder")
                {
                    GridMeeting.Visibility = Windows.UI.Xaml.Visibility.Visible;
                    GridStudy.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
                }
                else if (reminder == "Study Reminder")
                {
                    GridMeeting.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
                    GridStudy.Visibility = Windows.UI.Xaml.Visibility.Visible;
                }
            }
        }

        private async void ButtonAdd_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(textboxSubject.Text.Trim()))
            {
                await new MessageDialog("Type information").ShowAsync();
                return;
            }

            if (subjects == null)
                subjects = new ObservableCollection<string>();

            subjects.Add(textboxSubject.Text.Trim());
            textboxSubject.Text = "";
            ComboboxSubjects.ItemsSource = subjects;

            if (ComboboxSubjects.Items.Count > 0)
                App.jsonHelper.SerializeReminderData(subjects, "Subjects.txt");
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxMeetingWith.Text.Trim()))
            {
                await new MessageDialog("Type information").ShowAsync();
                return;
            }

            if (meetingWith == null)
                meetingWith = new ObservableCollection<string>();

            meetingWith.Add(textBoxMeetingWith.Text.Trim());
            textBoxMeetingWith.Text = "";
            ComboboxMeetingWith.ItemsSource = meetingWith;

            ComboboxMeetingWith.Visibility = Windows.UI.Xaml.Visibility.Visible;

            if (meetingWith.Count > 1)
                textBlockNumberofMembers.Text = "You have meeting with " + meetingWith[0] + " and " + (meetingWith.Count-1) + " other";
            else if (meetingWith.Count == 1)
                textBlockNumberofMembers.Text = "You have meeting with " + meetingWith[0] + " only, you can add more";
        }

        private async void ButtonNext_Click(object sender, RoutedEventArgs e)
        {
            if (await Validation())
            {
                Frame.Navigate(typeof(AddReminder2), Getparameter());
            }
        }

        private async Task<bool> Validation()
        {
            string reminder = ComboboxReminderType.SelectedValue as string;

            if (reminder == "Meeting Reminder")
            {
                if (meetingWith.Count < 1)
                {
                    await new MessageDialog("Add Members for meeting").ShowAsync();
                    return false;
                }

                if (string.IsNullOrEmpty(textBoxMeetingAgenda.Text))
                {
                    await new MessageDialog("Type meeting agends").ShowAsync();
                    return false;
                }

                if(string.IsNullOrEmpty((string)ComboBoxPriority.SelectedValue))
                {
                    await new MessageDialog("Select Priority").ShowAsync();
                    return false;
                }

                return true;
            }
            else if (reminder == "Study Reminder")
            {
                if (string.IsNullOrEmpty((string)ComboboxStudyType.SelectedValue))
                {
                    await new MessageDialog("Select study type").ShowAsync();
                    return false;
                }

                if (string.IsNullOrEmpty((string)ComboboxSubjects.SelectedValue))
                {
                    await new MessageDialog("Select subject").ShowAsync();
                    return false;

                }

                if (string.IsNullOrEmpty(textboxTitle.Text))
                {
                    await new MessageDialog("Type title").ShowAsync();
                    return false;
                }

                if (string.IsNullOrEmpty((string)ComboBoxPriority.SelectedValue))
                {
                    await new MessageDialog("Select Priority").ShowAsync();
                    return false;
                }

                return true;
            }
            else
            {
                await new MessageDialog("Select reminder type").ShowAsync();
                return false;
            }
        }

        private dynamic Getparameter()
        {
            dynamic expando = new ExpandoObject();
            if (GridMeeting.Visibility == Windows.UI.Xaml.Visibility.Visible)
            {
                expando.Type = "GridMeeting";
                expando.MeetingWith = meetingWith;
                expando.Agenda = textBoxMeetingAgenda.Text;
                DateTime startDateTime = new DateTime(DatePickerstartdate.Date.Year, DatePickerstartdate.Date.Month, DatePickerstartdate.Date.Day, TimePickerstarttime.Time.Hours, TimePickerstarttime.Time.Minutes, TimePickerstarttime.Time.Seconds);
                DateTime EndDateTime = new DateTime(DatePickerenddate.Date.Year, DatePickerenddate.Date.Month, DatePickerenddate.Date.Day, TimePickerendtime.Time.Hours, TimePickerendtime.Time.Minutes, TimePickerendtime.Time.Seconds);
                expando.StartDate = startDateTime.ToString();
                expando.EndDate = EndDateTime.ToString();
            }
            else if (GridStudy.Visibility == Windows.UI.Xaml.Visibility.Visible)
            {
                expando.Type = "GridStudy";
                expando.StudyType = ComboboxStudyType.SelectedValue as string;
                expando.Subject = ComboboxSubjects.SelectedValue as string;
                expando.Title = textboxTitle.Text;
                expando.Description = textboxDescription.Text;
                DateTime startDateTime = new DateTime(DatePickerduedate.Date.Year, DatePickerduedate.Date.Month, DatePickerduedate.Date.Day, TimePickerduetime.Time.Hours, TimePickerduetime.Time.Minutes, TimePickerduetime.Time.Seconds);
                expando.DueDate = startDateTime.ToString();
            }

            expando.Priority = ComboBoxPriority.SelectedValue as string;
            return expando;
        }

        private void AppBarButton_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(UpcommingReminders));
        }

        private void AppBarButton_Click_1(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPage));
        }
    }
}
