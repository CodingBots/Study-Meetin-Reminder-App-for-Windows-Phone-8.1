﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at http://go.microsoft.com/fwlink/?LinkId=234236

namespace Meeting_Reminder
{
    public sealed partial class UcMainpageControls : UserControl
    {
        public static readonly DependencyProperty ImageSouceProperty = DependencyProperty.Register("ImageSouce", typeof(String), typeof(UcMainpageControls), new PropertyMetadata(@"Assets/Icon.png"));
        public String ImageSouce
        {
            get
            {
                return (String)this.GetValue(ImageSouceProperty);
            }
            set
            {

                this.SetValue(ImageSouceProperty, value);
            }
        }

        public static readonly DependencyProperty TitleProperty = DependencyProperty.Register("Title", typeof(String), typeof(UcMainpageControls), new PropertyMetadata("Title"));
        public String Title
        {
            get
            {
                return (String)this.GetValue(TitleProperty);
            }
            set
            {
                this.SetValue(TitleProperty, value);
            }
        }

        public event RoutedEventHandler Click;

        private void grid_Tapped(object sender, TappedRoutedEventArgs e)
        {
            if (Click != null)
            {
                Click(this, new RoutedEventArgs());
            }
        }
        public UcMainpageControls()
        {
            this.InitializeComponent();
        }
    }
}
