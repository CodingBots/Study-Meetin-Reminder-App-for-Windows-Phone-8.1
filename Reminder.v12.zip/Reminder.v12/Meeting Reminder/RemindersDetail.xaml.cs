﻿using Meeting_Reminder.Common;
using SharedLibraries;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI;
using Windows.UI.Popups;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Basic Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace Meeting_Reminder
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class RemindersDetail : Page
    {
        internal Reminder reminder;

        private NavigationHelper navigationHelper;
        private ObservableDictionary defaultViewModel = new ObservableDictionary();

        public RemindersDetail()
        {
            this.InitializeComponent();

            this.navigationHelper = new NavigationHelper(this);
            this.navigationHelper.LoadState += this.NavigationHelper_LoadState;
            this.navigationHelper.SaveState += this.NavigationHelper_SaveState;
        }

        /// <summary>
        /// Gets the <see cref="NavigationHelper"/> associated with this <see cref="Page"/>.
        /// </summary>
        public NavigationHelper NavigationHelper
        {
            get { return this.navigationHelper; }
        }

        /// <summary>
        /// Gets the view model for this <see cref="Page"/>.
        /// This can be changed to a strongly typed view model.
        /// </summary>
        public ObservableDictionary DefaultViewModel
        {
            get { return this.defaultViewModel; }
        }

        /// <summary>
        /// Populates the page with content passed during navigation.  Any saved state is also
        /// provided when recreating a page from a prior session.
        /// </summary>
        /// <param name="sender">
        /// The source of the event; typically <see cref="NavigationHelper"/>
        /// </param>
        /// <param name="e">Event data that provides both the navigation parameter passed to
        /// <see cref="Frame.Navigate(Type, Object)"/> when this page was initially requested and
        /// a dictionary of state preserved by this page during an earlier
        /// session.  The state will be null the first time a page is visited.</param>
        private void NavigationHelper_LoadState(object sender, LoadStateEventArgs e)
        {
        }

        /// <summary>
        /// Preserves state associated with this page in case the application is suspended or the
        /// page is discarded from the navigation cache.  Values must conform to the serialization
        /// requirements of <see cref="SuspensionManager.SessionState"/>.
        /// </summary>
        /// <param name="sender">The source of the event; typically <see cref="NavigationHelper"/></param>
        /// <param name="e">Event data that provides an empty dictionary to be populated with
        /// serializable state.</param>
        private void NavigationHelper_SaveState(object sender, SaveStateEventArgs e)
        {
        }

        #region NavigationHelper registration

        /// <summary>
        /// The methods provided in this section are simply used to allow
        /// NavigationHelper to respond to the page's navigation methods.
        /// <para>
        /// Page specific logic should be placed in event handlers for the  
        /// <see cref="NavigationHelper.LoadState"/>
        /// and <see cref="NavigationHelper.SaveState"/>.
        /// The navigation parameter is available in the LoadState method 
        /// in addition to page state preserved during an earlier session.
        /// </para>
        /// </summary>
        /// <param name="e">Provides data for navigation methods and event
        /// handlers that cannot cancel the navigation request.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            this.navigationHelper.OnNavigatedTo(e);

            reminder = e.Parameter as Reminder;

            if (reminder.Status == "Completed")
            {
                tbstatus.Foreground = new SolidColorBrush(Colors.Green);
                tbstatusmeeting.Foreground = new SolidColorBrush(Colors.Green);
            }
            else
            {
                tbstatus.Foreground = new SolidColorBrush(Colors.Red);
                tbstatusmeeting.Foreground = new SolidColorBrush(Colors.Red);
            }

            if (reminder.Type == "GridStudy")
            {
                StudyPanel.Visibility = Windows.UI.Xaml.Visibility.Visible;
                MeetingPanel.Visibility = Windows.UI.Xaml.Visibility.Collapsed;

                textBoxHeadinglarge.Text = reminder.StudyType;
                tbTitle.Text = reminder.Title;
                tbsubj.Text = reminder.Subject;
                tbinstr.Text = reminder.Instructor;
                if (reminder.Description == "")
                    tbdesc.Text = "No Details Provided";
                else
                    tbdesc.Text = reminder.Description;
                tbPriority.Text = reminder.Priority;
                tbdue.Text = reminder.DueDate;
                tbstatus.Text = reminder.Status;
                tbreminder.Text = reminder.ReminderDate;

                if (reminder.GroupMembers.Count > 0)
                {
                    int i = 1;
                    foreach (string member in reminder.GroupMembers)
                    {
                        if (i == reminder.GroupMembers.Count-1)
                            tbgroupmembers.Text += member.ToUpper() + " and " + Environment.NewLine;
                        else if (i == reminder.GroupMembers.Count)
                            tbgroupmembers.Text += member.ToUpper();
                        else
                            tbgroupmembers.Text += member.ToUpper() + ", " + Environment.NewLine;

                        i++;
                    }
                }
                else
                {
                    tbgroupmembers.Text += "This is individual work";
                }
            }
            else if (reminder.Type == "GridMeeting")
            {
                StudyPanel.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
                MeetingPanel.Visibility = Windows.UI.Xaml.Visibility.Visible;

                textBoxHeadinglarge.Text = "Meeting";
                tblocationmeeting.Text = reminder.Location;
                tbagenda.Text =  reminder.Agenda;
                tbstartmeeting.Text = reminder.StartDate;
                tbendmeeting.Text = reminder.EndDate;
                tbPrioritymeeting.Text = reminder.Priority;
                tbstatusmeeting.Text = reminder.Status;
                tbremindermeeting.Text = reminder.ReminderDate;

                if (reminder.MeetingWith.Count > 0)
                {
                    int i = 1;
                    foreach (string member in reminder.MeetingWith)
                    {
                        if (i == reminder.MeetingWith.Count - 1)
                            tbmeetingmembers.Text += member.ToUpper() + " and " + Environment.NewLine;
                        else if (i == reminder.MeetingWith.Count)
                            tbmeetingmembers.Text += member.ToUpper();
                        else
                            tbmeetingmembers.Text += member.ToUpper() + ", " + Environment.NewLine;

                        i++;
                    }
                }
                else
                {
                    tbmeetingmembers.Text += "ops, seems there is no member :/";
                }
            }
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            this.navigationHelper.OnNavigatedFrom(e);
        }

        #endregion


        private async void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (reminder.Status == "Incomplete")
            {
                ObservableCollection<Reminder> collection = new ObservableCollection<Reminder>(App.pendingReminders);

                foreach (Reminder item in collection)
                {
                    if (item.ID == reminder.ID)
                    {
                        collection.Remove(item);
                        break;
                    }
                }

                if (collection.Count != 0)
                {
                    App.jsonHelper.SerializeReminderData(collection, "PendingReminders.txt");
                    App.pendingReminders = new ObservableCollection<Reminder>(collection);
                }
                else
                {
                    App.pendingReminders = null;
                    App.jsonHelper.DeleteFile("PendingReminders.txt");
                }

                await new MessageDialog("Reminder Deleted").ShowAsync();
                this.Frame.Navigate(typeof(UpcommingReminders));
            }
            else if (reminder.Status == "Completed")
            {
                ObservableCollection<Reminder> collection = new ObservableCollection<Reminder>(App.completed);

                foreach (Reminder item in collection)
                {
                    if (item.ID == reminder.ID)
                    {
                        collection.Remove(item);
                        break;
                    }
                }

                if (collection.Count != 0)
                {
                    App.jsonHelper.SerializeReminderData(collection, "Completed.txt");
                    App.completed = new ObservableCollection<Reminder>(collection);
                }
                else
                {
                    App.completed = null;
                    App.jsonHelper.DeleteFile("Completed.txt");
                }

                await new MessageDialog("Reminder Deleted").ShowAsync();
                this.Frame.Navigate(typeof(Completed));
            }
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(AddReminder1));
        }

        private void View_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(UpcommingReminders));
        }
    }
}
